

object Main {
  
  def main(args: Array[String]):Unit={
  
  var atl1=new Atleta("sofia", "goggia", "ita", 21.35);
  var atl2=new Atleta("federica", "brigani", "ita", 23.42);
  var list:List[Atleta]=List(atl1,atl2)
  var g1=new Individuale("Discesa Libera", list, 1000)
  
  var at=new Atleta("A", "B", "ita", 57.32);
  var at1=new Atleta("A2", "B2", "ita", 57.32);
  var at2=new Atleta("C", "D", "swe", 56.97);
  var at3=new Atleta("C2", "D2", "swe", 56.97);
  var list2:List[Atleta]=List(at,at1,at2,at3)
  var g2=new Coppia("Slittino", list2, 1001)
  
  var listgare:List[Gara]= List(g1,g2)
  var gg=new GestoreGare(listgare)
  
  println("STAMPO GARE IN GESTIONE: ")
  gg.print
  
  var a=new Atleta("federica", "pellegrini", "ita", 47.12);
  var a1=new Atleta("katie", "ledecky", "usa", 48.32);
  var a2=new Atleta("emma", "mckeon", "aus", 46.82);
  var a3=new Atleta("veronika", "andrusenko", "rus", 47.60);
  var a4=new Atleta("siobhan", "haughey", "usa", 47.48);
  var a5=new Atleta("leah", "smith", "usa", 46.98);
  var a6=new Atleta("katinka", "hosszù", "hun", 48.33);
  var a7=new Atleta("charlotte", "bonnet", "fra", 49.01);
  var list3:List[Atleta]=List(a,a1,a2,a3,a4,a5,a6,a7)
  var g3=new Gruppo("100m Stile Libero", list3, 1002)
 
  println("\nAGGIUNGO GARA")
  gg.insert(g3)
  println("STAMPO GARE IN GESTIONE: ")
  gg.print()
  
  gg.find("G1002")
  
  gg.vincitoredisciplina

  
  }
}