
//Costruttore gestore gare
class GestoreGare(lg:List[Gara]) {
 
  //campi
  var lista:List[Gara]=lg;
  
  //metodi
  def insert(g:Gara)={
    lista :::=List(g) //inserisce in cima alla lista
  }
  //stampa
  def print()={
    def stampa(g:Gara)={ //funzione ausiliaria
      println("\n"+g.ID+" "+g.disciplina+" "+g.tipo+" ")
      println("\nPartecipanti: \n")
      g.printA
    }
    lista.foreach(stampa)
  }
  //cerca evento tramite l'ID
  def find(chiave:String):Boolean={
    var trovato:Boolean=false
    def trova(g:Gara):Boolean ={ //funzione ausiliaria
      if(g.ID==chiave) {
        trovato=true; println("EVENTO TROVATO: "+g.ID+" "+g.disciplina+" "+g.tipo)
      }
      trovato
    }
    lista.foreach(trova)
    trovato
  }
  def vincitoredisciplina()={
    def v(g:Gara)={ //funzione ausiliaria
      println("VINCITORE DISCIPLINA "+g.disciplina+": ")
      g.winner
    }
    lista.foreach(v)
  }
}

