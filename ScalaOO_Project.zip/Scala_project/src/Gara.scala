import java.util.ArrayList

//Costruttore Gara
class Gara(d:String, a:List[Atleta]){
  
  //campi
  var disciplina:String=d;
  var partecipanti:List[Atleta]= a;
  var tipo:String="";
  var ID:String="";
  
  //stampa lista di atleti partecipanti a una gara
   def printA(){
    def stampaA(a:Atleta)={ //funzione ausiliaria
      println(a.nome+" "+a.cognome+" "+a.nazione)
    }
    partecipanti.foreach(stampaA) //per ogni elemento di partecipanti esegue 
    //la funzione stampA
  }
   //stampa il vincitore di una gara
   def winner(){
     //inizializzo due variabili vuote nome e cognome dove salverò l'atleta con il tempo minore
     var t:Double=200
     var nome:String=""
     var cognome:String=""
     def mintempo(a:Atleta)={ //funzione ausiliaria
       if(a.tempo<t) //aggiorno dati di chi ha impiegato meno tempo
         t=a.tempo
         nome=a.nome
         cognome=a.cognome
     }
    partecipanti.foreach(mintempo)
    println(nome+" "+cognome+" "+t)
  }  
}
//sottoclasse Individuale estende Gara, eredita costruttore e metodi
class Individuale(d:String, a:List[Atleta], id:Int) extends Gara(d:String, a:List[Atleta]){
  if(id>9999 || id<1000) println("errore id")
  else
   this.ID="I"+id;
   this.tipo="Individuale";
}
//sottoclasse Coppia estende Gara, eredita costruttore e metodi
class Coppia(d:String, a:List[Atleta], id:Int) extends Gara(d:String, a:List[Atleta]){
   if(id>9999 || id<1000) println("errore id")
   else
   this.ID="C"+id;
   this.tipo="Coppia";
}
//sottoclasse Gruppo estende Gara, eredita costruttore e metodi
class Gruppo(d:String, a:List[Atleta], id:Int) extends Gara(d:String, a:List[Atleta]){
   if(id>9999 || id<1000) println("errore id")
   else
   this.ID="G"+id;
   this.tipo="Gruppo";
}
