
//Costruttore classe Atleta
class Atleta(n:String, c:String, naz:String, t:Double){
  
  //campi
  var nome:String=n;
  var cognome:String=c;
  var nazione:String=naz;
  var tempo:Double=t;
  
  //metodi
  def getName()=this.n;
  def getCognome()=this.c;
  def getNazione()=this.naz;
  def getTempo()=this.t;
}