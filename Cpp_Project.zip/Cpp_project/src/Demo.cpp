/*
 * Demo.cpp
 *
 *  Created on: 15 gen 2018
 *      Author: jacopoghisalberti
 */

#include <iostream>
#include "Calciatore.h"
#include "Portiere.h"
#include "Difensore.h"
#include "Centrocampista.h"
#include "Attaccante.h"
#include "Formazione.h"

int main() {

	//portiere
	Portiere* p= new Portiere("Gigi", "Buffon", "Italia", 32, 10, 15);
	//difensori
	Difensore* d1= new Difensore("Carles", "Puyol", "Spagna", 27, 11, 76);
	Difensore* d2= new Difensore("John", "Terry", "Inghilterra", 29, 9, 80);
	Difensore* d3= new Difensore("Philippe", "Lahm", "Germania", 24, 7, 56);
	Difensore* d4= new Difensore("Bixente", "Lizarazu", "Francia", 25, 12, 92);
	//centrocampisti
	Centrocampista* c1= new Centrocampista("Frank", "Ballack", "Germania", 27, 8, 75);
	Centrocampista* c2= new Centrocampista("Andrea", "Pirlo", "Italia", 23, 5, 63);
	Centrocampista* c3= new Centrocampista("Steve", "Gerrard", "Inghilterra", 25, 9, 66);
	Centrocampista* c4= new Centrocampista("Ronaldinho", "Gaúcho", "Brasile", 22, 10, 81);
	//attaccanti
	Attaccante* a1= new Attaccante("Roberto", "Baggio", "Italia", 31, 9, 12);
	Attaccante* a2= new Attaccante("Patrick", "Kluivert", "Olanda", 22, 7, 6);

	//nuova formazione
	Formazione *f= new Formazione;

	//aggiungere a formazione inizalmente vuota
	f->aggiungi(p);
	f->aggiungi(d1);
	f->aggiungi(d2);
	f->aggiungi(d3);
	f->aggiungi(d4);
	f->aggiungi(c1);
	f->aggiungi(c2);
	f->aggiungi(c3);
	f->aggiungi(c4);
	f->aggiungi(a1);
	f->aggiungi(a2);

	//prova metodi delle sottoclassi di Calciatore
	cout<<p->toString()<<endl;
	cout<<"media parate: "<<endl;
	cout<<p->calcolaParate()<<endl;
	cout<<d2->toString()<<endl;
	cout<<"media contrasti: "<<endl;
	cout<<d2->calcolaContrasti()<<endl;
	cout<<c3->toString()<<endl;
	cout<<"media passaggi riusciti: "<<endl;
	cout<<c3->calcolaPassaggi()<<endl;
	cout<<a1->toString()<<endl;
	cout<<"media goal: "<<endl;
	cout<<a1->calcolaGoal()<<endl;
	cout<<"età media formazione: "<<endl;

	//prova metodi formazione
	cout<<f->etaMedia()<<endl;
	cout<<"stampa formazione: "<<endl;
	f->stampa();
	f->piùPresenze();
	f->stampaNaz("Italia");
}


