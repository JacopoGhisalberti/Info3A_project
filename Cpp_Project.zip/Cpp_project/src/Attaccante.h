/*
 * Attaccante.h
 *
 *  Created on: 16 gen 2018
 *      Author: jacopoghisalberti
 */
using namespace std;
#include "Calciatore.h"

#ifndef ATTACCANTE_H_
#define ATTACCANTE_H_

class Attaccante: virtual public Calciatore{ //eredita pubblicamente da Calciatore
protected:
	float goal;
public:
	//costruttore
	Attaccante(string n, string c, string naz, float a, int pg, int g);
	//metodi
	void setGoal(int p);
	float calcolaGoal();
	virtual ~Attaccante(); //distruttore
	string toString();
};

#endif /* ATTACCANTE_H_ */
