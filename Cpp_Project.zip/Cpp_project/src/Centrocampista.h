/*
 * Centrocampista.h
 *
 *  Created on: 16 gen 2018
 *      Author: jacopoghisalberti
 */
using namespace std;
#include "Calciatore.h"

#ifndef CENTROCAMPISTA_H_
#define CENTROCAMPISTA_H_

class Centrocampista: virtual public Calciatore{ //eredita pubblicamente da Calciatore
protected:
	int passaggiriusciti;
public:
	//costruttore
	Centrocampista(string n, string c, string naz, float a, int pg, int pr);
	//metodi
	void setPassaggi(int pr);
	float calcolaPassaggi();
	virtual ~Centrocampista(); //distruttore
	string toString();
};

#endif /* CENTROCAMPISTA_H_ */
