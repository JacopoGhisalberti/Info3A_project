/*
 * Formazione.cpp
 *
 *  Created on: 16 gen 2018
 *      Author: jacopoghisalberti
 */

#include <iostream>
#include <string>
#include <vector>

using namespace std;

#include "Formazione.h"

Formazione::Formazione(){}

void Formazione::aggiungi(Calciatore *c){
	l.push_back( c ); //inserimento in coda
}
Formazione::~Formazione(){
	cout<<"delete Formazione"<<endl;
	free(this);
}
float Formazione::etaMedia(){
	float età=0;
	Calciatore *c;
	vector<Calciatore*> :: iterator x; //iteratore per scorrere il vettore
	for(x=l.begin(); x!=l.end();x++){
		c=*x;
		età=età+c->getEtà(); //estraggo età di ogni calciatore appartente alla formazione
	}
	float etàmedia=età/l.size(); //calcolo età media
	return etàmedia;
}

void Formazione::stampa() {
	Calciatore *c;
	vector<Calciatore*> :: iterator x;
	for (x = l.begin(); x != l.end();  x++){
		c = *x; //estraggo calciatore
		cout<<c->toString()<<endl; //stampo i paramentri di calciatore mediante il metodo toString
	}
}
void Formazione::piùPresenze(){
	int npresenze=0;
	string nome,cognome;
	Calciatore *c;
	vector<Calciatore*> :: iterator x;
	for (x = l.begin(); x != l.end();  x++){
			c = *x;
			if(c->getPartitegiocate()>npresenze){
				npresenze=c->getPartitegiocate();
				nome=c->getNome();
				cognome=c->getCognome();
			}
		}
	cout<<"giocatore con più presenze: "+nome+" "+cognome<<endl;
}
void Formazione::stampaNaz(string naz){
	Calciatore *c;
	vector<Calciatore*> :: iterator x;
	cout<<"Giocatori della nazione "+ naz +": "<<endl;
	for (x = l.begin(); x != l.end();  x++){
		c = *x;
		if(c->getNazione()==naz) {cout<<c->getNome()+" "+c->getCognome()<<endl;}//controllo della nazione e stampa
	}
}




