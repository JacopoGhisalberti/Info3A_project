/*
 * Formazione.h
 *
 *  Created on: 16 gen 2018
 *      Author: jacopoghisalberti
 */
#include <iostream>
#include <string>
#include <vector>

#include "Calciatore.h"

#ifndef FORMAZIONE_H_
#define FORMAZIONE_H_

class Formazione{
	protected:
	//inizializzazione di vector con elementi di classe Calciatore
		std::vector<Calciatore*> l;
	public:
		//costruttore
		Formazione();
		virtual ~Formazione(); //distruttore
		void aggiungi(Calciatore *p);
		void stampa();
		float etaMedia();
		void stampaNaz(string naz);
		void piùPresenze();
};

#endif /* FORMAZIONE_H_ */
