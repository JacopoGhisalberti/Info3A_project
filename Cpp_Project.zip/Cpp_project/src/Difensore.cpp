#include <iostream>
#include <string>

#include "Difensore.h"
#include "Calciatore.h"

Difensore::Difensore(string n, string c, string naz, float a, int pg, int cr):Calciatore(n,c,naz,a,pg){ //estende il costruttore di Calciatore
	contrastiriusciti=cr;
}
Difensore::~Difensore(){
	cout<<"delete Difensore"<<endl;
	free(this);
}
void Difensore::setContrasti(int cr){
	 contrastiriusciti=cr;
}
float Difensore::calcolaContrasti(){
	float cpp; //contrasti per partita
	return cpp=(float)contrastiriusciti/partitegiocate;
}
string Difensore::toString(){
	return nome+" "+cognome+" "+nazionalità;
}
