/*
 * Difensore.h
 *
 *  Created on: 15 gen 2018
 *      Author: jacopoghisalberti
 */

using namespace std;
#include "Calciatore.h"

#ifndef DIFENSORE_H_
#define DIFENSORE_H_

class Difensore: virtual public Calciatore{ //eredita pubblicamente da Calciatore
protected:
	int contrastiriusciti;
public:
	//costruttore
	Difensore(string n, string c, string naz, float a, int pg, int cr);
	//metodi
	void setContrasti(int cr);
	float calcolaContrasti();
	virtual ~Difensore(); //distruttore
	string toString();
};



#endif /* DIFENSORE_H_ */
