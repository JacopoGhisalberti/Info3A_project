#include <iostream>
#include <string>

#include "Calciatore.h" //includo l'header file
//ridefinizione del costruttore
Calciatore::Calciatore(string n, string c, string naz, float a, int pg){
	nome=n;
	cognome=c;
	nazionalità=naz;
	età=a;
	partitegiocate=pg;
}
//ridefinizione dei metodi
Calciatore::~Calciatore(){
	cout<<"delete Calciatore"<<endl;
	free(this);
}

int Calciatore::getPartitegiocate(){
	return partitegiocate;
}
string Calciatore::getNome(){
	return nome;
}
string Calciatore::getCognome(){
	return cognome;
}
string Calciatore::getNazione(){
	return nazionalità;
}
float Calciatore::getEtà(){
	return età;
}
string Calciatore::toString(){
	return nome+" "+cognome+" "+nazionalità;
}
