#include <iostream>
#include <string>

#include "Centrocampista.h"
#include "Calciatore.h"

Centrocampista::Centrocampista(string n, string c, string naz, float a, int pg, int pr):Calciatore(n,c,naz,a,pg){ //estende il costruttore di Calciatore
	passaggiriusciti=pr;
}
Centrocampista::~Centrocampista(){
	cout<<"delete Centrocampista"<<endl;
	free(this);
}
void Centrocampista::setPassaggi(int pr){
	 passaggiriusciti=pr;
}
float Centrocampista::calcolaPassaggi(){
	float prpp; //passaggi riusciti per partita
	return prpp=(float)passaggiriusciti/partitegiocate;
}
string Centrocampista::toString(){
	return nome+" "+cognome+" "+nazionalità;
}


