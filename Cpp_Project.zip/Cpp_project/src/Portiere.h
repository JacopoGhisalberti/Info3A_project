/*
 * Portiere.h
 *
 *  Created on: 15 gen 2018
 *      Author: jacopoghisalberti
 */
using namespace std;
#include "Calciatore.h"

#ifndef PORTIERE_H_
#define PORTIERE_H_

class Portiere: virtual public Calciatore{ //eredita pubblicamente dalla classe Calciatore
protected:
	int parate;
public:
	//costruttore
	Portiere(string n, string c, string naz, float a, int pg, int p);
	//metodi
	void setParate(int p);
	float calcolaParate();
	virtual ~Portiere(); //distruttore
	string toString();
};

#endif /* PORTIERE_H_ */
