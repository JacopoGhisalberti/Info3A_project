#include <iostream>
#include <string>

#include "Attaccante.h"
#include "Calciatore.h"

Attaccante::Attaccante(string n, string c, string naz, float a, int pg, int g):Calciatore(n,c,naz,a,pg){ //estende il costruttore di Calciatore
	goal=g;
}
Attaccante::~Attaccante(){
	cout<<"delete Attaccante"<<endl;
	free(this);
}
void Attaccante::setGoal(int g){
	 goal=g;
}
float Attaccante::calcolaGoal(){
	float gpp; //goal per partite
	return gpp=(float)goal/partitegiocate;
}
string Attaccante::toString(){
	return nome+" "+cognome+" "+nazionalità;
}
