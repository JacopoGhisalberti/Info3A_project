#include <iostream>
#include <string>

#include "Portiere.h"
#include "Calciatore.h"

Portiere::Portiere(string n, string c, string naz, float a, int pg, int p):Calciatore(n,c,naz,a,pg){ //estende il costruttore di Calciatore
	parate=p;
}
Portiere::~Portiere(){
	cout<<"delete Portiere"<<endl;
	free(this);
}
void Portiere::setParate(int p){
	 parate=p;
}
float Portiere::calcolaParate(){
	float ppp; //parate per partite giocate
	return ppp=(float)parate/partitegiocate;
}
string Portiere::toString(){
	return nome+" "+cognome+" "+nazionalità;
}
