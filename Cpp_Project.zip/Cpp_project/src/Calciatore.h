/*
 * Calciatore.h
 *
 *  Created on: 15 gen 2018
 *      Author: jacopoghisalberti
 */
#include <string>
using namespace std;

#ifndef CALCIATORE_H_
#define CALCIATORE_H_

//creo classe Calciatore
class Calciatore{
protected:
	float età;
	string nome;
	string cognome;
	string nazionalità;
	int partitegiocate;
public:
	//costruttore
	Calciatore(string n, string c, string naz, float a, int pg);
	//metodi
	string getNome();
	string getCognome();
	string getNazione();
	int getPartitegiocate();
	float getEtà();
	virtual ~Calciatore(); //distruttore
	virtual string toString(); //stampa

};
#endif /* CALCIATORE_H_ */
